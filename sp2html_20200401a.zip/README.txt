A utility to convert oracle statspack reports to html to present an
interface similar to AWR reports.

Release 0002

Installation
============

Windows
-------
Unzip the file somewhere convenient.
Edit javaenv.cmd to set JAVA_HOME to the location of your java installation.

@echo on
rem =
rem Edit JAVAHOME to point  to your java installation
rem =
set JAVAHOME=C:\Program Files\Java\jdk1.8.0_161
set JAVABIN=%JAVAHOME%\bin
set JAVACMD=%JAVABIN%\java

Usage
=====

Change to the directory containing the statspack reports.
Run sp2html.cmd

The initial prototype release has no command line options - it simply
processes all  *.lst files in the current directory.

For each statspack report in the current directory, sp2html will
produce an html file which looks like an AWR report, and a verbose
log file.

Input                           HTML                                Log
sp_102_110.lst      sp_102_110.html             sp_102_110.lst.log

Reporting Bugs
==============

If you encounter any bugs  please send the input file, the output file, the
log file and a description of the issue to sp2html@ponder-stibbons.com